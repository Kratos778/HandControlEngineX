# HandControlEngineX

Projeto Android reconstruído do zero (esqueleto funcional), porque o código
fonte original se perdeu — só existia o `.apk` compilado no GitHub. Este
projeto usa os mesmos nomes de pacote (`com.handcontrol.engine`) e a mesma
arquitetura que foi identificada a partir do APK antigo, mais os 3 upgrades
pedidos: gestos novos, calibração por 4 cantos, pinch com histerese.

## O que já está feito
- Estrutura Gradle completa e correta (compila com `gradle assembleDebug`).
- Câmara (CameraX) + ligação ao MediaPipe HandLandmarker.
- `ModelProvider` corrigido: tenta primeiro o modelo em `assets/`, só
  descarrega da internet como último recurso (isto resolve o bug original
  de "não aparece a mão").
- `PinchDetector`, `HandGestureClassifier`, `CursorCalibrator` — os 3
  upgrades pedidos, já ligados ao `HandTrackingEngine`.
- `ControlBus` → `HandControlAccessibilityService` a executar cliques/scroll/back.
- `DebugOverlayView` + `TestModeActivity` para veres os landmarks em ecrã.

## O que falta antes de compilar
1. **Colocar o modelo do MediaPipe em `app/src/main/assets/hand_landmarker.task`**
   Descarrega de:
   https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
   (não incluí o ficheiro aqui por ter ~8MB de binário).
2. **`CameraTrackingService.processImage()`** tem um TODO: falta converter
   `ImageProxy` (formato YUV da câmara) para `Bitmap` antes de chamar
   `trackingEngine.processFrame(...)`. É um passo padrão do CameraX + MediaPipe
   (procura "CameraX ImageProxy to Bitmap MediaPipe" — há exemplos oficiais
   da Google prontos a copiar).
3. **Ícone da app** (`@mipmap/ic_launcher`) — usa o wizard do Android Studio
   (botão direito em `res` → New → Image Asset) para gerar um rápido.
4. **Layouts XML** das activities (`activity_main.xml`, etc.) — não incluí
   por serem só UI; o Android Studio consegue gerar um layout mínimo
   automaticamente ao abrir o projeto.

## Como pôr isto no GitHub
```bash
# dentro desta pasta HandControlEngineX/
git init
git remote add origin <URL-do-teu-repo>
git add .
git commit -m "Reconstroi projeto fonte completo + upgrades de gestos"
git branch -M main
git push -u origin main --force
```
`--force` porque o repo só tinha o `.apk` solto — isto substitui por um
projeto real. Se preferires não perder o `.apk` antigo, cria antes uma tag
ou branch separada com o estado atual do repo.

Depois do push, o `.github/workflows/build.yml` corre automaticamente e
gera um APK novo em "Actions" → artefactos.
