package com.handcontrol.engine.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Placeholder — liga aqui as opções de sensibilidade do cursor
 * (smoothingAlpha e deadZone do CursorCalibrator), e a escolha de quais
 * gestos ficam ativos.
 */
class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
