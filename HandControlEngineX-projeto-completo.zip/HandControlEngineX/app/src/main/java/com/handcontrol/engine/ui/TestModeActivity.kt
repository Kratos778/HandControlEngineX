package com.handcontrol.engine.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.handcontrol.engine.debug.DebugOverlayView

/**
 * Modo de teste: mostra a preview da câmara com o DebugOverlayView por
 * cima, para veres os landmarks/skeleton em tempo real sem afetar o resto
 * do sistema (sem despachar ações para o AccessibilityService).
 */
class TestModeActivity : AppCompatActivity() {

    private lateinit var overlayView: DebugOverlayView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overlayView = DebugOverlayView(this)
        setContentView(overlayView)
    }
}
