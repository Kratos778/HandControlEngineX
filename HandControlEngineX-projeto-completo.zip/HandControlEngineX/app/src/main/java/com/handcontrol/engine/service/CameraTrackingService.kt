package com.handcontrol.engine.service

import android.app.*
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import com.handcontrol.engine.debug.DebugOverlayView
import com.handcontrol.engine.tracking.HandTrackingEngine
import java.util.concurrent.Executors

/**
 * Serviço em foreground que mantém a câmara ativa e alimenta o
 * HandTrackingEngine frame a frame, mesmo com o ecrã de MainActivity em
 * segundo plano.
 */
class CameraTrackingService : Service() {

    private lateinit var trackingEngine: HandTrackingEngine
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var debugOverlay: DebugOverlayView? = null

    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "hand_control_tracking"
        private const val NOTIFICATION_ID = 1
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()

        val metrics = resources.displayMetrics
        trackingEngine = HandTrackingEngine(
            context = this,
            screenWidth = metrics.widthPixels,
            screenHeight = metrics.heightPixels,
            onLandmarksForDebugOverlay = { result -> debugOverlay?.updateResult(result) }
        )

        startCamera()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy: ImageProxy ->
                processImage(imageProxy)
            }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    androidx.lifecycle.ProcessLifecycleOwner.get(),
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    analysis
                )
            } catch (e: Exception) {
                // TODO: reportar falha de binding da câmara (ex.: já em uso por outra app)
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    private fun processImage(imageProxy: ImageProxy) {
        // TODO: converter imageProxy para Bitmap (ex.: via YuvToRgbConverter)
        // e chamar trackingEngine.processFrame(bitmap, imageProxy.imageInfo.timestamp)
        imageProxy.close()
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Controlo por gestos ativo",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("HandControlEngineX")
            .setContentText("A seguir os gestos da tua mão")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        trackingEngine.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
