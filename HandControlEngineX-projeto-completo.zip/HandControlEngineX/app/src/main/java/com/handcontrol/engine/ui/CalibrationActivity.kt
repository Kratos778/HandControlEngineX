package com.handcontrol.engine.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.handcontrol.engine.tracking.CursorCalibrator

/**
 * Fluxo simples de calibração: pede ao utilizador para apontar para cada
 * um dos 4 cantos do ecrã (com um pinch para confirmar cada ponto), grava
 * com o CursorCalibrator.
 *
 * Esta é a base — falta ligar aos eventos reais da câmara/HandTrackingEngine
 * (o botão/gesto de "confirmar canto" deve chamar recordCurrentCorner()
 * com a posição atual do indicador).
 */
class CalibrationActivity : AppCompatActivity() {

    private lateinit var calibrator: CursorCalibrator
    private val cornerOrder = listOf(
        CursorCalibrator.Corner.TOP_LEFT,
        CursorCalibrator.Corner.TOP_RIGHT,
        CursorCalibrator.Corner.BOTTOM_LEFT,
        CursorCalibrator.Corner.BOTTOM_RIGHT
    )
    private var currentCornerIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        calibrator = CursorCalibrator(this)
    }

    /** Chamar quando o utilizador confirma o canto atual (ex.: com um pinch). */
    fun recordCurrentCorner(handX: Float, handY: Float) {
        if (currentCornerIndex >= cornerOrder.size) return

        calibrator.recordCorner(cornerOrder[currentCornerIndex], handX, handY)
        currentCornerIndex++

        if (currentCornerIndex == cornerOrder.size) {
            calibrator.finishCalibration()
            finish()
        }
    }

    fun currentCornerLabel(): String = when (cornerOrder.getOrNull(currentCornerIndex)) {
        CursorCalibrator.Corner.TOP_LEFT -> "Aponta para o canto superior esquerdo"
        CursorCalibrator.Corner.TOP_RIGHT -> "Aponta para o canto superior direito"
        CursorCalibrator.Corner.BOTTOM_LEFT -> "Aponta para o canto inferior esquerdo"
        CursorCalibrator.Corner.BOTTOM_RIGHT -> "Aponta para o canto inferior direito"
        null -> "Calibração concluída"
    }
}
