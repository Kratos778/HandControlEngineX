package com.handcontrol.engine.tracking

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.sqrt

enum class Gesture {
    NONE,
    POINT,          // só o indicador esticado
    FIST,           // punho fechado
    OPEN_PALM,      // mão toda aberta
    THUMBS_UP,      // polegar esticado para cima, resto fechado
    PEACE_SIGN,     // indicador + médio esticados, resto fechado
    TWO_FINGER_SCROLL, // igual ao peace sign, mas usado para scroll vertical
    SWIPE_LEFT,
    SWIPE_RIGHT
}

/**
 * Classifica o gesto atual da mão a partir dos 21 landmarks do MediaPipe
 * HandLandmarker. O pinch NÃO está aqui — fica no PinchDetector, que tem
 * lógica própria de histerese/estado.
 *
 * Heurística usada para "dedo esticado": a ponta do dedo está mais longe do
 * pulso do que a articulação PIP. É simples e barato (sem precisar de
 * ângulos), e funciona bem o suficiente para gestos discretos como estes.
 */
class HandGestureClassifier(
    private val swipeVelocityThreshold: Float = 0.9f, // unidades normalizadas / segundo
    private val swipeCooldownMs: Long = 400L
) {

    private var lastWristX: Float? = null
    private var lastTimestampMs: Long = 0L
    private var lastSwipeAtMs: Long = 0L

    fun classify(landmarks: List<NormalizedLandmark>, nowMs: Long): Gesture {
        if (landmarks.size < 21) return Gesture.NONE

        val wrist = landmarks[0]

        val thumbExtended = isExtended(landmarks[2], landmarks[3], landmarks[4], wrist)
        val indexExtended = isExtended(landmarks[5], landmarks[6], landmarks[8], wrist)
        val middleExtended = isExtended(landmarks[9], landmarks[10], landmarks[12], wrist)
        val ringExtended = isExtended(landmarks[13], landmarks[14], landmarks[16], wrist)
        val pinkyExtended = isExtended(landmarks[17], landmarks[18], landmarks[20], wrist)

        val extendedCount = listOf(indexExtended, middleExtended, ringExtended, pinkyExtended)
            .count { it }

        // swipe tem prioridade quando a mão está aberta e se move depressa
        val swipe = detectSwipe(wrist.x(), nowMs, handIsOpen = extendedCount >= 3)
        if (swipe != Gesture.NONE) return swipe

        return when {
            extendedCount == 0 && !thumbExtended -> Gesture.FIST
            extendedCount == 4 && thumbExtended -> Gesture.OPEN_PALM
            thumbExtended && extendedCount == 0 -> Gesture.THUMBS_UP
            indexExtended && middleExtended && !ringExtended && !pinkyExtended -> Gesture.PEACE_SIGN
            indexExtended && !middleExtended && !ringExtended && !pinkyExtended -> Gesture.POINT
            else -> Gesture.NONE
        }
    }

    /**
     * Chamar isto especificamente quando já se sabe que o gesto é
     * PEACE_SIGN/dois dedos e se quer usar como scroll: devolve o delta
     * vertical (positivo = scroll para baixo) desde o frame anterior.
     */
    fun scrollDelta(landmarks: List<NormalizedLandmark>, previousAvgY: Float?): Pair<Float, Float> {
        val avgY = (landmarks[8].y() + landmarks[12].y()) / 2f
        val delta = if (previousAvgY != null) avgY - previousAvgY else 0f
        return delta to avgY
    }

    private fun detectSwipe(wristX: Float, nowMs: Long, handIsOpen: Boolean): Gesture {
        val prevX = lastWristX
        val prevT = lastTimestampMs
        lastWristX = wristX
        lastTimestampMs = nowMs

        if (prevX == null || prevT == 0L || !handIsOpen) return Gesture.NONE
        if (nowMs - lastSwipeAtMs < swipeCooldownMs) return Gesture.NONE

        val dtSeconds = (nowMs - prevT).coerceAtLeast(1L) / 1000f
        val velocity = (wristX - prevX) / dtSeconds

        return when {
            velocity > swipeVelocityThreshold -> {
                lastSwipeAtMs = nowMs
                Gesture.SWIPE_RIGHT
            }
            velocity < -swipeVelocityThreshold -> {
                lastSwipeAtMs = nowMs
                Gesture.SWIPE_LEFT
            }
            else -> Gesture.NONE
        }
    }

    private fun isExtended(
        mcp: NormalizedLandmark,
        pip: NormalizedLandmark,
        tip: NormalizedLandmark,
        wrist: NormalizedLandmark
    ): Boolean {
        val tipToWrist = dist(tip, wrist)
        val pipToWrist = dist(pip, wrist)
        // margem de 10% para não oscilar perto do limite
        return tipToWrist > pipToWrist * 1.1f
    }

    private fun dist(a: NormalizedLandmark, b: NormalizedLandmark): Float {
        val dx = a.x() - b.x()
        val dy = a.y() - b.y()
        return sqrt(dx * dx + dy * dy)
    }
}
