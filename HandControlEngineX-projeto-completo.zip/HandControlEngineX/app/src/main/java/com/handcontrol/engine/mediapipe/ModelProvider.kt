package com.handcontrol.engine.mediapipe

import android.content.Context
import android.util.Log
import java.io.File
import java.net.URL

/**
 * CORREÇÃO DO BUG ORIGINAL:
 * A versão anterior descarregava sempre o hand_landmarker.task da internet
 * no primeiro arranque (para hand_landmarker.task.part, depois renomeado).
 * Se isso falhasse — sem rede, timeout, .part corrompido de uma tentativa
 * anterior — o modelo nunca carregava e não aparecia mão nem landmark
 * nenhum.
 *
 * Esta versão tenta primeiro o modelo embutido em assets/ (funciona
 * sempre, mesmo offline). Só cai para download se não encontrar nada em
 * assets — e nesse caso limpa qualquer .part órfão antes de tentar.
 *
 * IMPORTANTE: para isto funcionar tens de colocar o ficheiro
 * hand_landmarker.task dentro de app/src/main/assets/. Descarrega-o de:
 * https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
 * (fica com ~8MB, aumenta o APK mas elimina esta classe de bugs).
 */
class ModelProvider(private val context: Context) {

    companion object {
        private const val TAG = "ModelProvider"
        private const val MODEL_FILENAME = "hand_landmarker.task"
        private const val DOWNLOAD_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
    }

    /**
     * Devolve o caminho absoluto para um hand_landmarker.task utilizável.
     * Prioridade: assets embutidos > cache local já descarregada > download novo.
     */
    fun resolveModelPath(): String {
        assetsModelBytesOrNull()?.let { bytes ->
            val cached = File(context.filesDir, MODEL_FILENAME)
            if (!cached.exists() || cached.length() != bytes.size.toLong()) {
                cached.writeBytes(bytes)
            }
            Log.i(TAG, "A usar modelo embutido em assets/")
            return cached.absolutePath
        }

        val existing = File(context.filesDir, MODEL_FILENAME)
        if (existing.exists() && existing.length() > 0) {
            Log.i(TAG, "A usar modelo já descarregado anteriormente")
            return existing.absolutePath
        }

        Log.w(TAG, "Modelo não embutido nos assets — a tentar download (precisa de internet)")
        return downloadModelBlocking()
    }

    private fun assetsModelBytesOrNull(): ByteArray? {
        return try {
            context.assets.open(MODEL_FILENAME).use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Download síncrono simples. Chamar sempre fora da main thread.
     * Limpa qualquer .part órfão antes, para nunca reutilizar um download
     * incompleto de uma tentativa anterior.
     */
    private fun downloadModelBlocking(): String {
        val finalFile = File(context.filesDir, MODEL_FILENAME)
        val partFile = File(context.filesDir, "$MODEL_FILENAME.part")

        if (partFile.exists()) {
            Log.w(TAG, "A apagar .part órfão de tentativa anterior")
            partFile.delete()
        }

        URL(DOWNLOAD_URL).openStream().use { input ->
            partFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }

        if (!partFile.renameTo(finalFile)) {
            throw IllegalStateException("Falha ao finalizar download do modelo")
        }

        Log.i(TAG, "Modelo descarregado com sucesso")
        return finalFile.absolutePath
    }
}
