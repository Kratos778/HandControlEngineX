package com.handcontrol.engine.debug

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * View de debug que desenha os 21 landmarks + conexões do esqueleto da mão
 * por cima da preview da câmara. Útil para confirmar visualmente que o
 * tracking está a funcionar (ver TestModeActivity).
 */
class DebugOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val pointPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
        strokeWidth = 8f
    }
    private val linePaint = Paint().apply {
        color = Color.YELLOW
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    // pares de índices dos ossos da mão, para desenhar as ligações
    private val connections = listOf(
        0 to 1, 1 to 2, 2 to 3, 3 to 4,          // polegar
        0 to 5, 5 to 6, 6 to 7, 7 to 8,          // indicador
        0 to 9, 9 to 10, 10 to 11, 11 to 12,     // médio
        0 to 13, 13 to 14, 14 to 15, 15 to 16,   // anelar
        0 to 17, 17 to 18, 18 to 19, 19 to 20    // mindinho
    )

    private var latestResult: HandLandmarkerResult? = null

    fun updateResult(result: HandLandmarkerResult?) {
        latestResult = result
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val result = latestResult ?: return

        result.landmarks().forEach { landmarks ->
            connections.forEach { (startIdx, endIdx) ->
                val start = landmarks.getOrNull(startIdx) ?: return@forEach
                val end = landmarks.getOrNull(endIdx) ?: return@forEach
                canvas.drawLine(
                    toPx(start).first, toPx(start).second,
                    toPx(end).first, toPx(end).second,
                    linePaint
                )
            }
            landmarks.forEach { point ->
                val (px, py) = toPx(point)
                canvas.drawCircle(px, py, 6f, pointPaint)
            }
        }
    }

    private fun toPx(landmark: NormalizedLandmark): Pair<Float, Float> {
        return landmark.x() * width to landmark.y() * height
    }
}
