package com.handcontrol.engine.tracking

import android.graphics.PointF

/**
 * Ponto único por onde passam todas as ações derivadas de gestos, antes de
 * chegarem ao AccessibilityService. Mantém o tracking (câmara/MediaPipe)
 * desacoplado da execução das ações no sistema.
 */
sealed class ControlAction {
    data class MoveCursor(val point: PointF) : ControlAction()
    data class ClickDown(val point: PointF) : ControlAction()
    data class ClickUp(val point: PointF) : ControlAction()
    data class Scroll(val deltaY: Float) : ControlAction()
    object NavigateBack : ControlAction()
    object NavigateForward : ControlAction()
}

object ControlBus {
    private val listeners = mutableListOf<(ControlAction) -> Unit>()

    fun subscribe(listener: (ControlAction) -> Unit) {
        listeners.add(listener)
    }

    fun unsubscribe(listener: (ControlAction) -> Unit) {
        listeners.remove(listener)
    }

    fun dispatch(action: ControlAction) {
        listeners.forEach { it(action) }
    }

    fun dispatchPinch(event: PinchDetector.PinchEvent) {
        when (event) {
            is PinchDetector.PinchEvent.PinchStart ->
                dispatch(ControlAction.ClickDown(PointF(event.x, event.y)))
            is PinchDetector.PinchEvent.PinchMove ->
                dispatch(ControlAction.MoveCursor(PointF(event.x, event.y)))
            is PinchDetector.PinchEvent.PinchEnd ->
                dispatch(ControlAction.ClickUp(PointF(event.x, event.y)))
        }
    }

    fun dispatchGesture(gesture: Gesture) {
        when (gesture) {
            Gesture.SWIPE_LEFT -> dispatch(ControlAction.NavigateBack)
            Gesture.SWIPE_RIGHT -> dispatch(ControlAction.NavigateForward)
            else -> Unit // outros gestos (FIST, OPEN_PALM, etc.) tratados no chamador
        }
    }
}
