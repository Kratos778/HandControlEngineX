package com.handcontrol.engine.mediapipe

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Envolve o HandLandmarker do MediaPipe Tasks Vision. Usa o ModelProvider
 * para resolver o caminho do modelo (assets embutidos com fallback para
 * download — ver ModelProvider.kt para o porquê).
 */
class HandLandmarkerManager(
    context: Context,
    maxHands: Int = 2,
    minHandDetectionConfidence: Float = 0.5f,
    minTrackingConfidence: Float = 0.5f,
    onResult: (HandLandmarkerResult) -> Unit,
    onError: (String) -> Unit
) {
    private val landmarker: HandLandmarker

    init {
        val modelPath = ModelProvider(context).resolveModelPath()

        val baseOptions = BaseOptions.builder()
            .setModelAssetPath(modelPath)
            .build()

        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(baseOptions)
            .setNumHands(maxHands)
            .setMinHandDetectionConfidence(minHandDetectionConfidence)
            .setMinTrackingConfidence(minTrackingConfidence)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ -> onResult(result) }
            .setErrorListener { error -> onError(error.message ?: "erro desconhecido no HandLandmarker") }
            .build()

        landmarker = HandLandmarker.createFromOptions(context, options)
    }

    fun detectAsync(bitmap: Bitmap, timestampMs: Long) {
        val mpImage = BitmapImageBuilder(bitmap).build()
        landmarker.detectAsync(mpImage, timestampMs)
    }

    fun close() {
        landmarker.close()
    }
}
