package com.handcontrol.engine.tracking

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.handcontrol.engine.mediapipe.HandLandmarkerManager

/**
 * Junta as peças todas: recebe frames da câmara, passa-os ao
 * HandLandmarkerManager, e para cada mão detetada corre o PinchDetector e o
 * HandGestureClassifier, despachando o resultado para o ControlBus.
 */
class HandTrackingEngine(
    context: Context,
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val onLandmarksForDebugOverlay: (HandLandmarkerResult?) -> Unit = {}
) {
    private val pinchDetector = PinchDetector()
    private val gestureClassifier = HandGestureClassifier()
    private val calibrator = CursorCalibrator(context)

    private val manager = HandLandmarkerManager(
        context = context,
        onResult = { result -> handleResult(result) },
        onError = { error -> onLandmarksForDebugOverlay(null) }
    )

    fun processFrame(bitmap: Bitmap, timestampMs: Long) {
        manager.detectAsync(bitmap, timestampMs)
    }

    private fun handleResult(result: HandLandmarkerResult) {
        onLandmarksForDebugOverlay(result)

        result.landmarks().forEachIndexed { index, landmarks ->
            val handId = HandId(index = index, isRightHand = true) // TODO: usar handedness() real
            val nowMs = System.currentTimeMillis()

            val pinchEvent = pinchDetector.update(handId, landmarks, nowMs)
            if (pinchEvent != null) {
                ControlBus.dispatchPinch(pinchEvent)
            } else {
                // sem pinch ativo: usa a ponta do indicador para mover o cursor
                val indexTip = landmarks[8]
                if (calibrator.isCalibrated()) {
                    calibrator.mapToScreen(indexTip.x(), indexTip.y(), screenWidth, screenHeight)
                        ?.let { ControlBus.dispatch(ControlAction.MoveCursor(it)) }
                }

                val gesture = gestureClassifier.classify(landmarks, nowMs)
                ControlBus.dispatchGesture(gesture)
            }
        }
    }

    fun close() {
        manager.close()
    }
}
