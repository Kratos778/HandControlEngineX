package com.handcontrol.engine.tracking

/**
 * Identifica uma mão específica ao longo do tempo (0 = primeira mão
 * detetada pelo MediaPipe neste frame, 1 = segunda, etc). O MediaPipe não
 * garante que o índice se mantém entre frames se uma mão desaparecer e
 * outra aparecer, mas para a maioria dos gestos de controlo (uma mão
 * principal) isto é suficiente.
 */
data class HandId(val index: Int, val isRightHand: Boolean)
