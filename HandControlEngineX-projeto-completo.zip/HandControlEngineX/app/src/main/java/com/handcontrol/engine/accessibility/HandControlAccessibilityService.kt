package com.handcontrol.engine.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.handcontrol.engine.tracking.ControlAction
import com.handcontrol.engine.tracking.ControlBus

/**
 * Recebe as ações já processadas do ControlBus (cursor, clique, scroll,
 * navegação) e executa-as como gestos de sistema via AccessibilityService.
 *
 * Nota: para o utilizador, ativar isto está em
 * Definições → Acessibilidade → HandControlEngineX → Ligar (é manual,
 * não há popup automático).
 */
class HandControlAccessibilityService : AccessibilityService() {

    private var pendingClickDownPath: Path? = null

    private val listener: (ControlAction) -> Unit = { action ->
        when (action) {
            is ControlAction.MoveCursor -> Unit // cursor visual gerido pelo overlay, não pelo dispatchGesture do sistema
            is ControlAction.ClickDown -> {
                pendingClickDownPath = Path().apply { moveTo(action.point.x, action.point.y) }
            }
            is ControlAction.ClickUp -> {
                val path = pendingClickDownPath ?: Path().apply { moveTo(action.point.x, action.point.y) }
                path.lineTo(action.point.x, action.point.y)
                dispatchTapGesture(path)
                pendingClickDownPath = null
            }
            is ControlAction.Scroll -> dispatchScrollGesture(action.deltaY)
            ControlAction.NavigateBack -> performGlobalAction(GLOBAL_ACTION_BACK)
            ControlAction.NavigateForward -> Unit // Android não tem "forward" global nativo
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        ControlBus.subscribe(listener)
    }

    override fun onDestroy() {
        ControlBus.unsubscribe(listener)
        super.onDestroy()
    }

    private fun dispatchTapGesture(path: Path) {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun dispatchScrollGesture(deltaY: Float) {
        val centerX = resources.displayMetrics.widthPixels / 2f
        val centerY = resources.displayMetrics.heightPixels / 2f
        val path = Path().apply {
            moveTo(centerX, centerY)
            lineTo(centerX, centerY - deltaY * 4f) // escala o gesto de scroll
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 120))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
