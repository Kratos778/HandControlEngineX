package com.handcontrol.engine.tracking

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.sqrt

/**
 * Deteta o gesto de "pinch" (polegar + indicador) de forma robusta.
 *
 * Problemas que este detetor resolve em relação a um cálculo simples de distância:
 * 1. Escala: a distância entre dedos muda com a distância da mão à câmara.
 *    Aqui normalizamos pela largura da palma (wrist -> middle_mcp), que é
 *    aproximadamente constante para a mesma mão, independente da profundidade.
 * 2. Jitter/flicker: usamos dois limiares diferentes para entrar e sair do
 *    pinch (histerese), para não ficar a piscar PINCH_START/PINCH_END quando
 *    o dedo está mesmo no limite.
 * 3. Debounce: ignora transições demasiado próximas no tempo (ruído do
 *    tracking frame a frame).
 */
class PinchDetector(
    private val pinchStartThreshold: Float = 0.32f,
    private val pinchEndThreshold: Float = 0.45f,
    private val minTransitionIntervalMs: Long = 80L
) {

    sealed class PinchEvent {
        data class PinchStart(val handId: HandId, val x: Float, val y: Float) : PinchEvent()
        data class PinchMove(val handId: HandId, val x: Float, val y: Float) : PinchEvent()
        data class PinchEnd(val handId: HandId, val x: Float, val y: Float) : PinchEvent()
    }

    private data class HandPinchState(
        var isPinching: Boolean = false,
        var lastTransitionAtMs: Long = 0L
    )

    private val stateByHand = mutableMapOf<HandId, HandPinchState>()

    /**
     * Chamar uma vez por frame, por cada mão detetada.
     * Devolve um PinchEvent se algo relevante aconteceu neste frame, ou null.
     */
    fun update(
        handId: HandId,
        landmarks: List<NormalizedLandmark>,
        nowMs: Long
    ): PinchEvent? {
        if (landmarks.size < 21) return null

        val wrist = landmarks[0]
        val middleMcp = landmarks[9]
        val thumbTip = landmarks[4]
        val indexTip = landmarks[8]

        val handScale = distance(wrist.x(), wrist.y(), middleMcp.x(), middleMcp.y())
        if (handScale < 1e-4f) return null // mão degenerada/sem leitura fiável

        val rawDistance = distance(thumbTip.x(), thumbTip.y(), indexTip.x(), indexTip.y())
        val normalizedDistance = rawDistance / handScale

        val midX = (thumbTip.x() + indexTip.x()) / 2f
        val midY = (thumbTip.y() + indexTip.y()) / 2f

        val state = stateByHand.getOrPut(handId) { HandPinchState() }
        val elapsedSinceTransition = nowMs - state.lastTransitionAtMs

        return when {
            !state.isPinching && normalizedDistance < pinchStartThreshold -> {
                if (elapsedSinceTransition < minTransitionIntervalMs) return null
                state.isPinching = true
                state.lastTransitionAtMs = nowMs
                PinchEvent.PinchStart(handId, midX, midY)
            }
            state.isPinching && normalizedDistance > pinchEndThreshold -> {
                if (elapsedSinceTransition < minTransitionIntervalMs) return null
                state.isPinching = false
                state.lastTransitionAtMs = nowMs
                PinchEvent.PinchEnd(handId, midX, midY)
            }
            state.isPinching -> PinchEvent.PinchMove(handId, midX, midY)
            else -> null
        }
    }

    /** Chamar quando uma mão deixa de ser detetada, para limpar o estado. */
    fun clearHand(handId: HandId) {
        stateByHand.remove(handId)
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return sqrt(dx * dx + dy * dy)
    }
}
