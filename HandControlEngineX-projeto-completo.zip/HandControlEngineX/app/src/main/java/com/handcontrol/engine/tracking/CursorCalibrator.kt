package com.handcontrol.engine.tracking

import android.content.Context
import android.graphics.PointF

/**
 * Calibração de cursor por 4 cantos, em vez de um simples min/max linear.
 *
 * Porquê 4 cantos e não min/max: a câmara pode estar ligeiramente
 * inclinada/rodada em relação ao ecrã, e a zona confortável de movimento da
 * mão raramente é um retângulo perfeito alinhado aos eixos. Guardando os 4
 * cantos (topo-esq, topo-dir, baixo-esq, baixo-dir) e fazendo interpolação
 * bilinear, o mapeamento fica correto mesmo com essa distorção.
 */
class CursorCalibrator(context: Context) {

    enum class Corner { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

    private val prefs = context.getSharedPreferences("hand_control_calibration", Context.MODE_PRIVATE)

    private var topLeft: PointF? = null
    private var topRight: PointF? = null
    private var bottomLeft: PointF? = null
    private var bottomRight: PointF? = null

    // suavização exponencial do cursor (reduz jitter linha-a-linha do tracking)
    private var smoothedX: Float? = null
    private var smoothedY: Float? = null
    var smoothingAlpha: Float = 0.35f // 0 = sem suavização, 1 = totalmente suavizado (mais lag)

    // zona-morta: ignora micro-movimentos abaixo deste valor (em coordenadas normalizadas 0-1)
    var deadZone: Float = 0.004f

    init {
        load()
    }

    fun isCalibrated(): Boolean =
        topLeft != null && topRight != null && bottomLeft != null && bottomRight != null

    fun recordCorner(corner: Corner, handX: Float, handY: Float) {
        val point = PointF(handX, handY)
        when (corner) {
            Corner.TOP_LEFT -> topLeft = point
            Corner.TOP_RIGHT -> topRight = point
            Corner.BOTTOM_LEFT -> bottomLeft = point
            Corner.BOTTOM_RIGHT -> bottomRight = point
        }
    }

    fun finishCalibration(): Boolean {
        if (!isCalibrated()) return false
        save()
        resetSmoothing()
        return true
    }

    fun reset() {
        topLeft = null
        topRight = null
        bottomLeft = null
        bottomRight = null
        resetSmoothing()
        prefs.edit().clear().apply()
    }

    fun resetSmoothing() {
        smoothedX = null
        smoothedY = null
    }

    /**
     * Mapeia a posição da mão (coordenadas normalizadas 0-1 da câmara) para
     * coordenadas de ecrã em pixels, aplicando interpolação bilinear pelos
     * 4 cantos calibrados, depois suavização, depois zona-morta.
     */
    fun mapToScreen(handX: Float, handY: Float, screenWidth: Int, screenHeight: Int): PointF? {
        val tl = topLeft ?: return null
        val tr = topRight ?: return null
        val bl = bottomLeft ?: return null
        val br = bottomRight ?: return null

        // Resolve (u, v) em [0,1]x[0,1] tal que a interpolação bilinear dos 4
        // cantos dê (handX, handY). Aproximação por Newton em poucas iterações
        // é suficiente para esta escala de erro.
        var u = 0.5f
        var v = 0.5f
        repeat(6) {
            val estX = bilinear(tl.x, tr.x, bl.x, br.x, u, v)
            val estY = bilinear(tl.y, tr.y, bl.y, br.y, u, v)
            val errX = handX - estX
            val errY = handY - estY

            val dxU = (bilinear(tl.x, tr.x, bl.x, br.x, u + 0.01f, v) - estX) / 0.01f
            val dyV = (bilinear(tl.y, tr.y, bl.y, br.y, u, v + 0.01f) - estY) / 0.01f

            if (abs(dxU) > 1e-5f) u += errX / dxU * 0.5f
            if (abs(dyV) > 1e-5f) v += errY / dyV * 0.5f
            u = u.coerceIn(-0.3f, 1.3f)
            v = v.coerceIn(-0.3f, 1.3f)
        }

        val clampedU = u.coerceIn(0f, 1f)
        val clampedV = v.coerceIn(0f, 1f)

        val rawScreenX = clampedU * screenWidth
        val rawScreenY = clampedV * screenHeight

        val prevX = smoothedX
        val prevY = smoothedY
        val outX = if (prevX == null) rawScreenX else lerp(prevX, rawScreenX, 1f - smoothingAlpha)
        val outY = if (prevY == null) rawScreenY else lerp(prevY, rawScreenY, 1f - smoothingAlpha)

        // zona-morta: se o movimento é minúsculo, mantém a posição anterior
        if (prevX != null && prevY != null) {
            val deadZonePx = deadZone * screenWidth
            if (abs(outX - prevX) < deadZonePx && abs(outY - prevY) < deadZonePx) {
                return PointF(prevX, prevY)
            }
        }

        smoothedX = outX
        smoothedY = outY
        return PointF(outX, outY)
    }

    private fun bilinear(tl: Float, tr: Float, bl: Float, br: Float, u: Float, v: Float): Float {
        val top = lerp(tl, tr, u)
        val bottom = lerp(bl, br, u)
        return lerp(top, bottom, v)
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
    private fun abs(x: Float): Float = if (x < 0f) -x else x

    private fun save() {
        prefs.edit()
            .putFloat("tl_x", topLeft!!.x).putFloat("tl_y", topLeft!!.y)
            .putFloat("tr_x", topRight!!.x).putFloat("tr_y", topRight!!.y)
            .putFloat("bl_x", bottomLeft!!.x).putFloat("bl_y", bottomLeft!!.y)
            .putFloat("br_x", bottomRight!!.x).putFloat("br_y", bottomRight!!.y)
            .apply()
    }

    private fun load() {
        if (!prefs.contains("tl_x")) return
        topLeft = PointF(prefs.getFloat("tl_x", 0f), prefs.getFloat("tl_y", 0f))
        topRight = PointF(prefs.getFloat("tr_x", 1f), prefs.getFloat("tr_y", 0f))
        bottomLeft = PointF(prefs.getFloat("bl_x", 0f), prefs.getFloat("bl_y", 1f))
        bottomRight = PointF(prefs.getFloat("br_x", 1f), prefs.getFloat("br_y", 1f))
    }
}
